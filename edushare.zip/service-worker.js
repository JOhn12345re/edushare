const CACHE_NAME = 'edushare-cache-v14-' + Date.now();
const ASSETS = [
  './',
  './index.html',
  './styles.css',
  './app.js',
  './manifest.webmanifest',
  './icon.svg'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS))
  );
  self.skipWaiting();
  // Forcer l'activation immédiate
  self.clients.claim();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(
      keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))
    ))
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  const url = new URL(req.url);
  const isApi = /\/api-php\//.test(url.pathname) || url.pathname.endsWith('/resources.php') || url.pathname.endsWith('/upload.php');
  if (isApi) {
    // Bypass cache for API calls
    event.respondWith(fetch(req).catch(() => fetch(req)));
    return;
  }
  event.respondWith(
    caches.match(req).then((cached) => cached || fetch(req).then((res) => {
      const resClone = res.clone();
      caches.open(CACHE_NAME).then((cache) => cache.put(req, resClone)).catch(()=>{});
      return res;
    }).catch(() => cached))
  );
});


