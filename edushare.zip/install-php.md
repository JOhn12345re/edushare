# 🚀 Guide d'installation PHP pour Windows + Cursor

## 📥 Étape 1 : Télécharger PHP

1. **Allez sur le site officiel :** https://windows.php.net/download/
2. **Téléchargez** la version **PHP 8.3 NTS x64 Thread Safe** (fichier ZIP)
3. **Ou utilisez ce lien direct :** https://windows.php.net/downloads/releases/php-8.3.14-nts-Win32-vs16-x64.zip

## 📂 Étape 2 : Installation

1. **Créer le dossier :** `C:\php` (déjà fait ✅)
2. **Extraire** le contenu du ZIP téléchargé dans `C:\php`
3. **Vérifier** que vous avez maintenant : `C:\php\php.exe`

## ⚙️ Étape 3 : Configuration du PATH

### Option A : Via l'interface Windows
1. **Ouvrir** Paramètres Windows > Système > À propos > Paramètres système avancés
2. **Cliquer** sur "Variables d'environnement"
3. **Sélectionner** "Path" dans les variables système
4. **Cliquer** "Modifier" puis "Nouveau"
5. **Ajouter** : `C:\php`
6. **Valider** et fermer toutes les fenêtres

### Option B : Via PowerShell (ADMIN)
```powershell
# Exécuter PowerShell en tant qu'administrateur
[Environment]::SetEnvironmentVariable("Path", $env:Path + ";C:\php", [EnvironmentVariableTarget]::Machine)
```

## 🔧 Étape 4 : Configuration PHP

1. **Copier** le fichier `C:\php\php.ini-development` vers `C:\php\php.ini`
2. **Activer** les extensions nécessaires dans `php.ini` :

```ini
extension=pdo_sqlite
extension=sqlite3
extension=curl
extension=mbstring
extension=openssl
```

## ✅ Étape 5 : Vérification

Ouvrir un **nouveau** terminal PowerShell et taper :
```powershell
php --version
```

## 🎯 Étape 6 : Configuration Cursor

1. **Installer l'extension PHP** : Ouvrir Cursor > Extensions > Rechercher "PHP" > Installer "PHP Intelephense"
2. **Redémarrer** Cursor
3. **Ouvrir** votre projet EduShare dans Cursor

## 🚀 Étape 7 : Lancer le serveur

```powershell
cd "C:\Users\sheno\OneDrive\Bureau\EduShare"
php -S 127.0.0.1:8001 -t api-php
```

---

## 🔧 Alternative : Installation via Chocolatey

Si vous préférez un gestionnaire de paquets :

1. **Installer Chocolatey** (en PowerShell ADMIN) :
```powershell
Set-ExecutionPolicy Bypass -Scope Process -Force; [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
```

2. **Installer PHP** :
```powershell
choco install php
```

---

## ❗ Problèmes courants

- **"php" non reconnu** → Redémarrer le terminal après avoir modifié le PATH
- **Permission refusée** → Exécuter PowerShell en tant qu'administrateur
- **Extensions manquantes** → Vérifier le fichier `php.ini`
