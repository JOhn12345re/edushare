<?php
// Configuration de la base de données pour EduShare
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=utf-8');

// Gestion des requêtes OPTIONS (préflight CORS)
if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Configuration base de données MySQL (XAMPP)
$host = 'localhost';
$dbname = 'edushare';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
} catch (PDOException $e) {
    // Si MySQL n'est pas disponible, utiliser SQLite comme fallback
    try {
        $pdo = new PDO('sqlite:' . __DIR__ . '/../data/edushare.db');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        
        // Créer les tables SQLite si elles n'existent pas
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS resources (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                university TEXT,
                year TEXT,
                subject TEXT,
                class_level TEXT,
                type TEXT DEFAULT 'autre',
                description TEXT,
                url TEXT,
                file_path TEXT,
                is_public INTEGER DEFAULT 1,
                author_name TEXT,
                author_email TEXT,
                is_anonymous INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ");
        
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS comments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                resource_id INTEGER,
                content TEXT NOT NULL,
                author_name TEXT,
                user_id INTEGER DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (resource_id) REFERENCES resources(id) ON DELETE CASCADE
            )
        ");
        
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS ratings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                resource_id INTEGER,
                rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
                user_id INTEGER DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (resource_id) REFERENCES resources(id) ON DELETE CASCADE
            )
        ");
        
    } catch (PDOException $e2) {
        echo json_encode(['error' => 'Erreur de base de données: ' . $e2->getMessage()]);
        exit();
    }
}

// Fonctions utilitaires
function sendJson($data) {
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit();
}

function sendError($message, $code = 400) {
    http_response_code($code);
    sendJson(['error' => $message, 'ok' => false]);
}

function sendSuccess($data = [], $message = 'Success') {
    sendJson(['ok' => true, 'message' => $message, 'data' => $data]);
}
?>
