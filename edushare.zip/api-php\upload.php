<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Méthode non autorisée');
}

if (!isset($_FILES['file'])) {
    sendError('Aucun fichier reçu');
}

$file = $_FILES['file'];

// Vérifications de base
if ($file['error'] !== UPLOAD_ERR_OK) {
    sendError('Erreur lors du téléchargement: ' . $file['error']);
}

$maxSize = 20 * 1024 * 1024; // 20 Mo
if ($file['size'] > $maxSize) {
    sendError('Fichier trop volumineux (max 20 Mo)');
}

// Types de fichiers autorisés
$allowedTypes = [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-powerpoint',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'text/plain',
    'application/zip',
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp',
    'image/svg+xml'
];

$allowedExtensions = [
    'pdf','doc','docx','ppt','pptx','txt','zip','jpg','jpeg','png','gif','webp','svg'
];

$extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
if (!in_array($file['type'], $allowedTypes) && !in_array($extension, $allowedExtensions)) {
    sendError('Type de fichier non autorisé');
}

// Créer le dossier uploads (dans le répertoire de l'API) s'il n'existe pas
$uploadDir = __DIR__ . '/uploads/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// Générer un nom de fichier unique
$fileName = uniqid() . '.' . $extension;
$filePath = $uploadDir . $fileName;

// Déplacer le fichier
if (move_uploaded_file($file['tmp_name'], $filePath)) {
    sendSuccess([
        'file_path' => 'uploads/' . $fileName,
        'original_name' => $file['name'],
        'size' => $file['size'],
        'type' => $file['type']
    ], 'Fichier téléchargé avec succès');
} else {
    sendError('Erreur lors de la sauvegarde du fichier');
}
?>
