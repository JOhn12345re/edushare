# Script pour configurer PHP dans le PATH
# À exécuter en tant qu'administrateur

Write-Host "🔧 Configuration du PATH pour PHP..." -ForegroundColor Yellow

# Vérifier si PHP existe
if (Test-Path "C:\php\php.exe") {
    Write-Host "✅ PHP trouvé dans C:\php" -ForegroundColor Green
    
    # Ajouter au PATH si pas déjà présent
    $currentPath = [Environment]::GetEnvironmentVariable("Path", [EnvironmentVariableTarget]::Machine)
    if ($currentPath -notlike "*C:\php*") {
        Write-Host "➕ Ajout de C:\php au PATH..." -ForegroundColor Yellow
        [Environment]::SetEnvironmentVariable("Path", $currentPath + ";C:\php", [EnvironmentVariableTarget]::Machine)
        Write-Host "✅ PATH configuré avec succès!" -ForegroundColor Green
    } else {
        Write-Host "ℹ️ C:\php est déjà dans le PATH" -ForegroundColor Blue
    }
    
    # Créer php.ini si nécessaire
    if (-not (Test-Path "C:\php\php.ini")) {
        if (Test-Path "C:\php\php.ini-development") {
            Write-Host "📄 Création du fichier php.ini..." -ForegroundColor Yellow
            Copy-Item "C:\php\php.ini-development" "C:\php\php.ini"
            Write-Host "✅ php.ini créé!" -ForegroundColor Green
        }
    }
    
    Write-Host "🎉 Configuration terminée!" -ForegroundColor Green
    Write-Host "💡 Redémarrez votre terminal pour utiliser PHP" -ForegroundColor Yellow
    
} else {
    Write-Host "❌ PHP non trouvé dans C:\php" -ForegroundColor Red
    Write-Host "📥 Veuillez d'abord télécharger et extraire PHP dans C:\php" -ForegroundColor Yellow
    Write-Host "🔗 Lien : https://windows.php.net/download/" -ForegroundColor Blue
}

Read-Host "Appuyez sur Entrée pour continuer..."
