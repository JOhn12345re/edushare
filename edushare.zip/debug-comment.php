<?php
// Test rapide des commentaires via XAMPP
header('Content-Type: application/json; charset=utf-8');

echo "=== Debug Commentaires ===\n";

// Simuler une requête de commentaire
$_SERVER['REQUEST_METHOD'] = 'POST';
$_GET['action'] = 'add_comment';

// Données de test
$testData = [
    'resource_id' => 25,
    'author_name' => 'Test User',
    'comment' => 'Test commentaire'
];

// Simuler l'input JSON
$GLOBALS['_test_input'] = json_encode($testData);

// Override file_get_contents pour le test
function file_get_contents($filename) {
    if ($filename === 'php://input') {
        return $GLOBALS['_test_input'];
    }
    return call_user_func_array('file_get_contents', func_get_args());
}

try {
    ob_start();
    include 'api-php/resources.php';
    $output = ob_get_clean();
    
    echo "Résultat API:\n";
    echo $output;
} catch (Exception $e) {
    echo "Erreur: " . $e->getMessage() . "\n";
}
?>
