<?php
require_once 'config.php';

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'list':
        listResources();
        break;
    case 'create':
        createResource();
        break;
    case 'update':
        updateResource();
        break;
    case 'delete':
        deleteResource();
        break;
    case 'add_comment':
        addComment();
        break;
    case 'add_rating':
        addRating();
        break;
    case 'delete_comment':
        deleteComment();
        break;
    default:
        sendError('Action non reconnue');
}

function listResources() {
    global $pdo;
    
    try {
        // Récupérer les ressources avec leurs statistiques
        $sql = "
            SELECT r.*,
                   AVG(rt.rating) as avg_rating,
                   COUNT(DISTINCT rt.id) as rating_count,
                   COUNT(DISTINCT c.id) as comment_count
            FROM resources r
            LEFT JOIN ratings rt ON r.id = rt.resource_id
            LEFT JOIN comments c ON r.id = c.resource_id
            WHERE r.is_public = 1
            GROUP BY r.id
            ORDER BY r.created_at DESC
        ";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $resources = $stmt->fetchAll();
        
        // Ajouter les commentaires à chaque ressource
        foreach ($resources as &$resource) {
            // Vérifier existence du fichier dans api-php/uploads ou, à défaut, dans ../uploads
            if (!empty($resource['file_path'])) {
                $rel = ltrim($resource['file_path'], '/');
                $absApi = __DIR__ . '/' . $rel; // api-php/uploads/...
                $absRoot = dirname(__DIR__) . '/uploads/' . basename($rel);
                if (is_file($absApi)) {
                    // ok
                } elseif (is_file($absRoot)) {
                    // Fichier à la racine: réécrire le chemin relatif pour être servi correctement depuis l'API
                    $resource['file_path'] = '../uploads/' . basename($rel);
                } else {
                    // Introuvable : masquer
                    $resource['file_path'] = null;
                }
            }
            $commentSql = "SELECT * FROM comments WHERE resource_id = ? ORDER BY created_at DESC";
            $commentStmt = $pdo->prepare($commentSql);
            $commentStmt->execute([$resource['id']]);
            $resource['comments'] = $commentStmt->fetchAll();
            
            // Arrondir la moyenne
            $resource['avg_rating'] = $resource['avg_rating'] ? round($resource['avg_rating'], 1) : 0;
        }
        
        sendJson($resources);
        
    } catch (PDOException $e) {
        sendError('Erreur lors de la récupération: ' . $e->getMessage());
    }
}

function createResource() {
    global $pdo;
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['title'])) {
        sendError('Données manquantes');
    }
    
    try {
        $sql = "INSERT INTO resources (title, university, year, subject, class_level, type, description, url, file_path, is_public, author_name, is_anonymous) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $input['title'],
            $input['university'] ?? '',
            $input['year'] ?? '',
            $input['subject'] ?? '',
            $input['classLevel'] ?? '',
            $input['type'] ?? 'autre',
            $input['description'] ?? '',
            $input['url'] ?? '',
            $input['file_path'] ?? null,
            isset($input['isPublic']) ? ($input['isPublic'] ? 1 : 0) : 1,
            $input['author_name'] ?? '',
            isset($input['is_anonymous']) ? ($input['is_anonymous'] ? 1 : 0) : 0
        ]);
        
        $newId = $pdo->lastInsertId();
        sendSuccess(['id' => $newId], 'Ressource créée');
        
    } catch (PDOException $e) {
        sendError('Erreur lors de la création: ' . $e->getMessage());
    }
}

function updateResource() {
    global $pdo;
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['id'])) {
        sendError('ID manquant');
    }
    
    try {
        $hasFile = isset($input['file_path']) && $input['file_path'] !== '';
        if ($hasFile) {
            $sql = "UPDATE resources SET title = ?, university = ?, year = ?, subject = ?, class_level = ?, type = ?, description = ?, url = ?, file_path = ?, is_public = ? WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $input['title'],
                $input['university'],
                $input['year'],
                $input['subject'],
                $input['classLevel'] ?? '',
                $input['type'] ?? 'autre',
                $input['description'] ?? '',
                $input['url'] ?? '',
                $input['file_path'],
                $input['isPublic'] ? 1 : 0,
                $input['id']
            ]);
        } else {
            $sql = "UPDATE resources SET title = ?, university = ?, year = ?, subject = ?, class_level = ?, type = ?, description = ?, url = ?, is_public = ? WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $input['title'],
                $input['university'],
                $input['year'],
                $input['subject'],
                $input['classLevel'] ?? '',
                $input['type'] ?? 'autre',
                $input['description'] ?? '',
                $input['url'] ?? '',
                $input['isPublic'] ? 1 : 0,
                $input['id']
            ]);
        }
        
        sendSuccess([], 'Ressource mise à jour');
        
    } catch (PDOException $e) {
        sendError('Erreur lors de la mise à jour: ' . $e->getMessage());
    }
}

function deleteResource() {
    global $pdo;
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['id'])) {
        sendError('ID manquant');
    }
    
    try {
        $sql = "DELETE FROM resources WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$input['id']]);
        
        sendSuccess([], 'Ressource supprimée');
        
    } catch (PDOException $e) {
        sendError('Erreur lors de la suppression: ' . $e->getMessage());
    }
}

function getJsonOrForm() {
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
    if (stripos($contentType, 'application/json') !== false) {
        $input = json_decode(file_get_contents('php://input'), true);
        return is_array($input) ? $input : [];
    }
    // Fallback form-data / x-www-form-urlencoded
    if (!empty($_POST)) return $_POST;
    $raw = file_get_contents('php://input');
    parse_str($raw, $out);
    return is_array($out) ? $out : [];
}

function addComment() {
    global $pdo;
    $input = getJsonOrForm();
    
    if (!$input || !isset($input['resource_id']) || !isset($input['content'])) {
        sendError('Données manquantes (resource_id, content requis)');
    }
    
    try {
        $sql = "INSERT INTO comments (resource_id, content, author_name) VALUES (?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $input['resource_id'],
            $input['content'],
            $input['author_name'] ?? 'Anonyme'
        ]);
        
        $newId = $pdo->lastInsertId();
        sendSuccess(['id' => $newId], 'Commentaire ajouté');
        
    } catch (PDOException $e) {
        sendError('Erreur lors de l\'ajout du commentaire: ' . $e->getMessage());
    }
}

function addRating() {
    global $pdo;
    $input = getJsonOrForm();
    
    if (!$input || !isset($input['resource_id']) || !isset($input['rating'])) {
        sendError('Données manquantes (resource_id, rating requis)');
    }
    
    $rating = intval($input['rating']);
    if ($rating < 1 || $rating > 5) {
        sendError('La note doit être entre 1 et 5');
    }
    
    try {
        // Vérifier si l'utilisateur a déjà noté (basé sur user_id = 1 pour l'instant)
        $checkSql = "SELECT id FROM ratings WHERE resource_id = ? AND user_id = 1";
        $checkStmt = $pdo->prepare($checkSql);
        $checkStmt->execute([$input['resource_id']]);
        
        if ($checkStmt->fetch()) {
            // Mettre à jour la note existante
            $sql = "UPDATE ratings SET rating = ? WHERE resource_id = ? AND user_id = 1";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$rating, $input['resource_id']]);
            sendSuccess([], 'Note mise à jour');
        } else {
            // Ajouter une nouvelle note
            $sql = "INSERT INTO ratings (resource_id, rating, user_id) VALUES (?, ?, 1)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$input['resource_id'], $rating]);
            
            $newId = $pdo->lastInsertId();
            sendSuccess(['id' => $newId], 'Note ajoutée');
        }
        
    } catch (PDOException $e) {
        sendError('Erreur lors de l\'ajout de la note: ' . $e->getMessage());
    }
}

function deleteComment() {
    global $pdo;
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['comment_id'])) {
        sendError('ID du commentaire manquant');
    }
    
    try {
        $sql = "DELETE FROM comments WHERE id = ? AND user_id = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$input['comment_id']]);
        
        sendSuccess([], 'Commentaire supprimé');
        
    } catch (PDOException $e) {
        sendError('Erreur lors de la suppression: ' . $e->getMessage());
    }
}
?>
