// Données et stockage local (sans base de données)
const STORAGE_KEYS = {
  USER: 'edushare:user',
  RESOURCES: 'edushare:resources',
  NOTIFICATIONS: 'edushare:notifications',
};
const FILEMAP_KEY = 'edushare:filemap';

const THEME_KEY = 'edushare:theme';
let themeMediaMql = null;

// Limite d'upload côté client
const MAX_UPLOAD_BYTES = 20 * 1024 * 1024; // 20 Mo

// Intégration API (MySQL via PHP)
const USE_API = true;
// Détection automatique: si servi par XAMPP sous /EduShare
const DEFAULT_API = 'http://127.0.0.1:8001';
const XAMPP_API = (typeof location !== 'undefined' && location.origin) ? (location.origin + '/EduShare/api-php') : DEFAULT_API;
const API_BASE = (typeof location !== 'undefined' && (()=>{ try { const p = new URL(location.href).pathname; return p === '/EduShare' || p.startsWith('/EduShare/'); } catch { return false; } })()) ? XAMPP_API : DEFAULT_API;
const API_ORIGIN = (()=>{ try{ return new URL(API_BASE).origin; } catch { return DEFAULT_API; } })();
// Servez toujours les fichiers depuis la racine de l'API (ex: http://localhost/EduShare/api-php/uploads/...)
const FILE_BASE = API_BASE.replace(/\/$/, '') + '/';

async function fetchJSON(url, options = {}) {
  const res = await fetch(url, options);
  const raw = await res.text();
  // Retire tous les BOM et espaces parasites
  let text = (raw || '').replace(/\uFEFF/g, '').trim();
  try {
    return JSON.parse(text);
  } catch (e1) {
    // Tentative de récupération: extraire le bloc JSON probable
    const firstBrace = text.indexOf('{');
    const firstBracket = text.indexOf('[');
    let start = -1;
    if (firstBrace === -1 && firstBracket === -1) {
      throw new Error(`Réponse non JSON (${res.status}): ${text.slice(0, 200)}`);
    }
    if (firstBrace === -1) start = firstBracket; else if (firstBracket === -1) start = firstBrace; else start = Math.min(firstBrace, firstBracket);
    const lastBrace = text.lastIndexOf('}');
    const lastBracket = text.lastIndexOf(']');
    const end = Math.max(lastBrace, lastBracket);
    if (start >= 0 && end > start) {
      const candidate = text.slice(start, end + 1);
      try {
        return JSON.parse(candidate);
      } catch (e2) {
        throw new Error(`Réponse non JSON (${res.status}): ${candidate.slice(0, 200)}`);
      }
    }
    throw new Error(`Réponse non JSON (${res.status}): ${text.slice(0, 200)}`);
  }
}

function buildFileUrl(resource) {
  if (!resource || !resource.filePath) return null;
  try { return new URL(resource.filePath, FILE_BASE).href; } catch { return FILE_BASE + resource.filePath; }
}

function normalizeResource(row) {
  if (!row) return null;
  const createdAtTs = row.created_at ? Date.parse(row.created_at) : Date.now();
  return {
    id: row.id ?? crypto.randomUUID(),
    title: row.title || '',
    university: row.university || '',
    year: row.year || '',
    subject: row.subject || '',
    classLevel: row.class_level || '',
    type: row.type || 'autre',
    description: row.description || '',
    url: row.url || '',
    filePath: row.file_path || null,
    isPublic: row.is_public ? Boolean(Number(row.is_public)) : true,
    createdAt: Number.isFinite(createdAtTs) ? createdAtTs : Date.now(),
    ratings: [],
    comments: [],
    authorEmail: row.author_email || '',
    authorName: row.author_name || '',
    isAnonymous: row.is_anonymous ? Boolean(Number(row.is_anonymous)) : false,
  };
}

async function apiListResources() {
  const data = await fetchJSON(`${API_BASE}/resources.php?action=list`, { method: 'GET' });
  if (!Array.isArray(data)) return [];
  return enrichWithLocalFiles(data.map(normalizeResource).filter(Boolean));
}

async function apiCreateResource(item) {
  const payload = {
    title: item.title,
    university: item.university,
    year: item.year,
    subject: item.subject,
    classLevel: item.classLevel || '',
    type: item.type || 'autre',
    description: item.description || '',
    url: item.url || '',
    file_path: item.filePath || null,
    isPublic: item.isPublic ? 1 : 0,
    author_name: item.authorName || '',
    is_anonymous: item.isAnonymous ? 1 : 0,
  };
  return fetchJSON(`${API_BASE}/resources.php?action=create`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
}

async function apiUploadFile(file) {
  const fd = new FormData();
  fd.append('file', file);
  const res = await fetch(`${API_BASE.replace(/\/$/, '')}/upload.php`, { method: 'POST', body: fd });
  const raw = await res.text();
  let txt = (raw || '').replace(/\uFEFF/g, '').trim();
  try { return JSON.parse(txt); } catch (e) {
    const i = Math.min(txt.indexOf('{'), txt.indexOf('[').toString()==='-1'?9999:txt.indexOf('['));
    const j = Math.max(txt.lastIndexOf('}'), txt.lastIndexOf(']'));
    if (i>=0 && j>i) return JSON.parse(txt.slice(i, j+1));
    throw new Error('Upload: réponse non JSON');
  }
}

// Upload via XHR pour suivre la progression
function uploadFileWithProgress(file, onProgress) {
  return new Promise((resolve, reject) => {
    try {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', `${API_BASE.replace(/\/$/, '')}/upload.php`);
      xhr.responseType = 'text';
      xhr.upload.onprogress = (e) => {
        if (!e.lengthComputable) return;
        const pct = Math.round((e.loaded / e.total) * 100);
        if (typeof onProgress === 'function') onProgress(pct);
      };
      xhr.onload = () => {
        const raw = (xhr.response || '').toString().replace(/\uFEFF/g, '').trim();
        try {
          const data = JSON.parse(raw);
          resolve(data);
        } catch (err) {
          // tentative d'extraction
          const i = Math.min(raw.indexOf('{'), raw.indexOf('[') === -1 ? 9999 : raw.indexOf('['));
          const j = Math.max(raw.lastIndexOf('}'), raw.lastIndexOf(']'));
          if (i>=0 && j>i) {
            try { resolve(JSON.parse(raw.slice(i, j+1))); return; } catch {}
          }
          reject(new Error('Upload: réponse non JSON'));
        }
      };
      xhr.onerror = () => reject(new Error('Erreur réseau upload'));
      const fd = new FormData();
      fd.append('file', file);
      xhr.send(fd);
    } catch (e) { reject(e); }
  });
}

function readStorage(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw);
  } catch (e) {
    console.error('readStorage error', key, e);
    return fallback;
  }
}

function writeStorage(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.error('writeStorage error', key, e);
  }
}

// Modèle de données simple
/**
 * Resource = {
 *   id, title, university, year, subject, classLevel, type, description, url?, isPublic, createdAt,
 *   ratings: number[], comments: {author, text, createdAt}[], authorEmail
 * }
 */

// Seed initial (optionnel)
function seedIfEmpty() {
  const existing = readStorage(STORAGE_KEYS.RESOURCES, []);
  if (existing.length === 0) {
    const sample = [
      {
        id: crypto.randomUUID(),
        title: 'Résumé Analyse - L1',
        university: 'Université A',
        year: 'L1',
        subject: 'Analyse',
        classLevel: 'L1',
        type: 'résumé',
        description: 'Résumé du chapitre dérivées et limites.',
        url: '',
        isPublic: true,
        createdAt: Date.now() - 1000 * 60 * 60 * 24 * 2,
        ratings: [4, 5, 5, 3],
        comments: [
          { authorKey: 'alice@example.com', authorDisplay: 'Alice', text: 'Très utile, merci !', createdAt: Date.now() - 1000000 },
        ],
        authorEmail: 'alice@example.com',
        authorKey: 'alice@example.com',
      },
      {
        id: crypto.randomUUID(),
        title: 'Cours de Mathématiques - Analyse L1',
        university: 'Université de Paris',
        year: 'L1',
        subject: 'Mathématiques',
        classLevel: 'L1',
        type: 'cours',
        description: 'Cours complet sur l\'analyse mathématique niveau L1',
        url: '',
        isPublic: true,
        createdAt: Date.now() - 1000 * 60 * 60 * 24 * 1,
        ratings: [5, 4, 5],
        comments: [
          { authorKey: 'prof@example.com', authorDisplay: 'Prof. Martin', text: 'Excellent travail !', createdAt: Date.now() - 800000 },
        ],
        authorEmail: 'prof@example.com',
        authorKey: 'prof@example.com',
      },
      {
        id: crypto.randomUUID(),
        title: 'Exercices Physique - Mécanique',
        university: 'Université Lyon',
        year: 'L2',
        subject: 'Physique',
        classLevel: 'L2',
        type: 'exercice',
        description: 'Série d\'exercices sur la mécanique newtonienne',
        url: '',
        isPublic: true,
        createdAt: Date.now() - 1000 * 60 * 60 * 12,
        ratings: [4, 4, 3, 5],
        comments: [],
        authorEmail: 'etudiant@example.com',
        authorKey: 'etudiant@example.com',
      }
    ];
    writeStorage(STORAGE_KEYS.RESOURCES, sample);
  }
  if (!readStorage(STORAGE_KEYS.NOTIFICATIONS, null)) {
    writeStorage(STORAGE_KEYS.NOTIFICATIONS, []);
  }
}

// Utilisateur courant
function getCurrentUser() {
  return readStorage(STORAGE_KEYS.USER, null);
}
function setCurrentUser(user) {
  writeStorage(STORAGE_KEYS.USER, user);
  renderAuth();
}
function getUserDisplay(user) {
  if (!user) return 'anonyme';
  if (user.isAnonymous) return 'anonyme';
  const first = (user.firstName || '').trim();
  const last = (user.lastName || '').trim();
  const full = `${first} ${last}`.trim();
  return full || user.school || 'anonyme';
}
function getUserKey(user) {
  if (!user) return 'anon';
  // Clé stable locale pour favoris/votes: priorité à email s'il existait déjà, sinon nom+école
  if (user.email) return user.email;
  const first = (user.firstName || '').trim().toLowerCase();
  const last = (user.lastName || '').trim().toLowerCase();
  const school = (user.school || '').trim().toLowerCase();
  return `name:${first}:${last}:school:${school}:anon:${user.isAnonymous?1:0}`;
}
function getResourceAuthorDisplay(resource) {
  if (!resource) return 'anonyme';
  if (resource.isAnonymous) return 'anonyme';
  return (resource.authorName || resource.authorEmail || 'anonyme');
}

// Utilitaires UI
function qs(sel) { return document.querySelector(sel); }
function el(tag, attrs = {}, children = []) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') node.className = v;
    else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.substring(2), v);
    else if (k === 'html') node.innerHTML = v;
    else node.setAttribute(k, v);
  }
  for (const child of [].concat(children)) {
    if (child == null) continue;
    node.appendChild(typeof child === 'string' ? document.createTextNode(child) : child);
  }
  return node;
}

// Toasts (notifications non bloquantes)
function ensureToastContainer() {
  let c = document.querySelector('.toast-container');
  if (!c) {
    c = document.createElement('div');
    c.className = 'toast-container';
    document.body.appendChild(c);
  }
  return c;
}
function toast(message, type = 'success', timeout = 2500) {
  const c = ensureToastContainer();
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.textContent = message;
  c.appendChild(t);
  setTimeout(() => t.remove(), timeout);
}

function formatDate(ts) {
  try { return new Date(ts).toLocaleString('fr-FR'); } catch { return ''; }
}

function averageRating(ratings) {
  if (!ratings || ratings.length === 0) return 0;
  const sum = ratings.reduce((a, b) => a + b, 0);
  return Math.round((sum / ratings.length) * 10) / 10;
}

function formatBytes(bytes) {
  if (bytes === 0) return '0 B';
  if (!bytes && bytes !== 0) return '';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${(bytes / Math.pow(k, i)).toFixed(1)} ${sizes[i]}`;
}

function readFileAsDataURL(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// Export / Import (localStorage)
function collectAllData() {
  const data = {};
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key && key.startsWith('edushare:')) {
      try { data[key] = JSON.parse(localStorage.getItem(key)); } catch { data[key] = localStorage.getItem(key); }
    }
  }
  return data;
}

function restoreAllData(snapshot) {
  if (!snapshot || typeof snapshot !== 'object') return false;
  for (const [key, value] of Object.entries(snapshot)) {
    if (!key.startsWith('edushare:')) continue;
    try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* ignore */ }
  }
  return true;
}

function downloadJSON(filename, obj) {
  const blob = new Blob([JSON.stringify(obj, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function favoritesKey(userKey) { return `edushare:favorites:${userKey}`; }
function getFavorites(userKey) { return new Set(readStorage(favoritesKey(userKey), [])); }
function setFavorites(userKey, idsSet) { writeStorage(favoritesKey(userKey), Array.from(idsSet)); }

// Ressources créées par l'utilisateur (IDs renvoyés par l'API)
function mineKey(userKey) { return `edushare:mine:${userKey}`; }
function getMineIds(userKey) { return new Set(readStorage(mineKey(userKey), [])); }
function addMineId(userKey, id) {
  const set = getMineIds(userKey);
  set.add(String(id));
  writeStorage(mineKey(userKey), Array.from(set));
}
function isOwnerResource(resource) {
  const user = getCurrentUser();
  if (!user) return false;
  const userKey = getUserKey(user);
  if (resource && resource.authorKey && resource.authorKey === userKey) return true;
  if (resource && resource.authorEmail && user.email && resource.authorEmail === user.email) return true;
  const myIds = getMineIds(userKey);
  return myIds.has(String(resource.id));
}

// Fichiers locaux associés aux IDs renvoyés par l'API (prévisualisation client)
function getFileMap() {
  return readStorage(FILEMAP_KEY, {});
}
function setFileMap(map) {
  writeStorage(FILEMAP_KEY, map || {});
}
function setFileMapItem(id, meta) {
  const map = getFileMap();
  map[String(id)] = meta;
  setFileMap(map);
}
function enrichWithLocalFiles(list) {
  const map = getFileMap();
  if (!list || !Array.isArray(list)) return list || [];
  return list.map(r => {
    const m = map[String(r.id)];
    if (m) {
      return { ...r, fileName: m.fileName, fileType: m.fileType, fileSize: m.fileSize, fileData: m.fileData };
    }
    return r;
  });
}

// Sauvegarde de la dernière recherche
const LAST_SEARCH_KEY = 'edushare:lastSearch';
function saveLastSearch(state) {
  try {
    writeStorage(LAST_SEARCH_KEY, {
      q: state.query, u: state.university, y: state.year,
      s: state.subject, c: state.classLevel, sort: state.sort, p: state.page
    });
  } catch {}
}
function loadLastSearch() {
  return readStorage(LAST_SEARCH_KEY, null);
}

// Router
const routes = {
  '/': renderHome,
  '/auth': renderAuthPage,
  '/recherche': renderSearch,
  '/partage': renderShare,
  '/details': renderDetails,
  '/profil': renderProfile,
  '/notifications': renderNotifications,
  '/aide': renderHelp,
};

function navigate(path) {
  window.location.hash = `#${path}`;
}
function getParamAsString(params, key) {
  const v = params.get(key);
  return v == null ? '' : String(v);
}

async function renderDetails() {
  const app = qs('#app');
  app.innerHTML = '';
  const params = getHashParams();
  const id = getParamAsString(params, 'id');
  if (!id) { app.append(el('div', { class: 'card' }, 'Ressource introuvable.')); return; }

  let resource = await findResourceById(id);
  if (!resource) { app.append(el('div', { class: 'card' }, 'Ressource introuvable.')); return; }

  const header = el('div', { class: 'card stack' }, [
    el('h2', {}, resource.title || 'Détails de la ressource'),
    el('div', { class: 'meta' }, [
      el('span', { class: 'chip' }, resource.university || ''),
      el('span', { class: 'chip' }, resource.year || ''),
      el('span', { class: 'chip' }, resource.subject || ''),
      el('span', { class: 'chip' }, resource.classLevel || ''),
      el('span', { class: 'chip' }, resource.type || 'autre'),
      el('span', { class: 'chip' }, resource.isPublic ? 'Public' : 'Privé'),
    ]),
    el('p', {}, resource.description || ''),
    el('div', { class: 'toolbar' }, [
      resource.url ? el('a', { class: 'btn secondary', href: resource.url, target: '_blank', rel: 'noopener' }, 'Ouvrir le lien') : null,
      (resource.fileData || resource.filePath) ? el('a', { class: 'btn secondary', href: resource.filePath ? (buildFileUrl(resource)) : resource.fileData, download: resource.fileName || 'fichier' }, 'Télécharger') : null,
      canPreview(resource) ? el('button', { class: 'btn', onclick: ()=> openPreview(resource) }, 'Prévisualiser') : null,
      el('a', { class: 'btn ghost', href: '#/recherche' }, '← Retour'),
    ])
  ]);

  const avg = USE_API ? (resource.avg_rating || 0) : averageRating(resource.ratings || []);
  const ratingCount = USE_API ? (resource.rating_count || 0) : (resource.ratings ? resource.ratings.length : 0);
  const ratingSection = el('div', { class: 'card stack' }, [
    el('h3', {}, 'Avis et évaluation'),
    el('div', { class: 'toolbar' }, [
      el('span', { class: 'rating' }, [
        ...[1,2,3,4,5].map(n => el('button', { class: 'btn ghost', title: `${n} étoile(s)`, onclick: ()=> rateResource(resource.id, n) }, String(n))),
        el('span', { class: 'muted' }, ` ${avg}/5 (${ratingCount})`)
      ])
    ])
  ]);

  const comments = USE_API ? (resource.comments || []) : (resource.comments || []);
  const user = getCurrentUser();
  const userKey = user ? getUserKey(user) : null;
  const commentsSection = el('div', { class: 'card stack' }, [
    el('h3', {}, 'Commentaires'),
    comments.length ? el('div', { class: 'list' }, comments.map((c, idx) => el('div', { class: 'list-item' }, [
      el('div', { class: 'muted' }, `${c.author_name || c.authorDisplay || c.author || 'anonyme'} — ${formatDate(c.created_at || c.createdAt || Date.now())}`),
      el('div', {}, c.content || c.text),
      (userKey && ((c.user_id && c.user_id == 1) || (c.authorKey && c.authorKey === userKey))) ? el('div', { class: 'toolbar' }, [
        el('button', { class: 'btn ghost', onclick: ()=> deleteComment(resource.id, c.id || idx) }, 'Supprimer')
      ]) : null,
    ]))) : el('div', { class: 'empty' }, 'Aucun commentaire pour le moment.'),
    user ? el('form', { onsubmit: (e)=>{ e.preventDefault(); submitComment(resource.id, e.target); } }, [
      el('label', { for: 'comment-text' }, 'Ajouter un commentaire'),
      el('textarea', { id: 'comment-text', name: 'text', required: true, placeholder: 'Votre commentaire...', onkeydown: (e)=>{ const k=e.key||''; if (k==='/'||k.toLowerCase()==='n'){ e.stopPropagation(); } } }),
      el('div', { class: 'toolbar' }, [ el('button', { class: 'btn' }, 'Publier') ])
    ]) : el('div', { class: 'toolbar' }, [ el('span', { class: 'muted' }, 'Connectez-vous pour commenter et noter.'), el('a', { class: 'btn', href: '#/auth' }, 'Se connecter') ])
  ]);

  app.append(header, ratingSection, commentsSection);
}

function getHashParts() {
  const raw = (window.location.hash || '#/').replace(/^#/, '');
  const [path, query = ''] = raw.split('?');
  return { path, query };
}

function getPath() {
  return getHashParts().path || '/';
}

function getHashParams() {
  return new URLSearchParams(getHashParts().query || '');
}

function setHashQuery(params) {
  const { path } = getHashParts();
  const q = params.toString();
  const newHash = `#${path}${q ? `?${q}` : ''}`;
  if (window.location.hash !== newHash) {
    window.location.hash = newHash;
  }
}

function router() {
  const path = getPath();
  const view = routes[path] || renderNotFound;
  view();
  window.scrollTo(0, 0);
  highlightActiveNav(path);
}
function highlightActiveNav(path) {
  try {
    const nav = document.querySelector('.main-nav');
    if (!nav) return;
    const links = Array.from(nav.querySelectorAll('a'));
    const map = {
      '/': '#/',
      '/recherche': '#/recherche',
      '/partage': '#/partage',
      '/notifications': '#/notifications',
      '/aide': '#/aide',
      '/auth': '#/auth',
      '/profil': '#/profil',
    };
    const current = map[path] || '#/';
    links.forEach(a => {
      if (a.getAttribute('href') === current) a.classList.add('active');
      else a.classList.remove('active');
    });
  } catch {}
}

// Composants communs
function renderAuth() {
  const slot = qs('#auth-slot');
  const user = getCurrentUser();
  slot.innerHTML = '';
  if (!user) {
    slot.append(
      el('button', { class: 'btn ghost', onclick: () => navigate('/auth') }, 'Se connecter')
    );
  } else {
    slot.append(
      el('span', { class: 'muted' }, getUserDisplay(user)),
      el('button', { class: 'btn', onclick: () => navigate('/profil') }, 'Profil'),
      el('button', { class: 'btn danger', onclick: () => { setCurrentUser(null); navigate('/'); } }, 'Déconnexion'),
    );
  }
}

// Boutons d'interface additionnels (ex: thème)
function renderHeaderExtras() {
  const ui = qs('#ui-slot');
  if (!ui) return;
  ui.innerHTML = '';
  const mode = getStoredTheme();
  const themeBtn = el(
    'button',
    { class: 'btn ghost', onclick: cycleTheme },
    mode === 'auto' ? '🖥️ Auto' : mode === 'dark' ? '☀️ Clair' : '🌙 Sombre'
  );
  const exportBtn = el('button', { class: 'btn ghost', onclick: () => downloadJSON(`edushare-export-${new Date().toISOString().slice(0,10)}.json`, collectAllData()) }, 'Exporter');
  const importInput = el('input', { type: 'file', accept: 'application/json', class: 'hidden', id: 'import-file' });
  importInput.addEventListener('change', async (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    try {
      const text = await file.text();
      const snapshot = JSON.parse(text);
      if (restoreAllData(snapshot)) {
        alert('Import réussi. Rechargement...');
        location.reload();
      } else {
        alert("Import invalide.");
      }
    } catch (err) {
      alert('Impossible de lire ce fichier.');
    }
  });
  const importBtn = el('button', { class: 'btn ghost', onclick: () => importInput.click() }, 'Importer');
  ui.append(themeBtn, exportBtn, importBtn, importInput);
}

function getStoredTheme() {
  return readStorage(THEME_KEY, null) || 'auto';
}
function currentTheme() {
  const stored = getStoredTheme();
  if (stored === 'auto') {
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }
  return stored;
}
function applyTheme(themeOrAuto) {
  const resolved = themeOrAuto === 'auto' ? currentTheme() : themeOrAuto;
  document.documentElement.setAttribute('data-theme', resolved);
}
function attachThemeListenerIfNeeded() {
  if (!window.matchMedia) return;
  if (getStoredTheme() !== 'auto') {
    if (themeMediaMql) { themeMediaMql.removeEventListener('change', onSystemThemeChange); themeMediaMql = null; }
    return;
  }
  if (!themeMediaMql) {
    themeMediaMql = window.matchMedia('(prefers-color-scheme: dark)');
    themeMediaMql.addEventListener('change', onSystemThemeChange);
  }
}
function onSystemThemeChange() {
  applyTheme('auto');
  renderHeaderExtras();
}
function setTheme(theme) {
  writeStorage(THEME_KEY, theme);
  attachThemeListenerIfNeeded();
  applyTheme(theme);
  renderHeaderExtras();
}
function cycleTheme() {
  const order = ['auto', 'light', 'dark'];
  const curr = getStoredTheme();
  const next = order[(order.indexOf(curr) + 1) % order.length];
  setTheme(next);
}

function resourceCard(resource) {
  // Utiliser les données de l'API si disponibles, sinon fallback localStorage
  const avg = USE_API ? (resource.avg_rating || 0) : averageRating(resource.ratings || []);
  const ratingCount = USE_API ? (resource.rating_count || 0) : (resource.ratings ? resource.ratings.length : 0);
  const comments = USE_API ? (resource.comments || []) : (resource.comments || []);
  
  const stars = '★★★★★'.split('').map((s, i) => el('span', { class: 'star', title: `${avg}/5` }, i < Math.round(avg) ? '★' : '☆'));
  const user = getCurrentUser();
  const userKey = user ? getUserKey(user) : null;
  const isOwner = user ? isOwnerResource(resource) : false;
  const favSet = userKey ? getFavorites(userKey) : new Set();
  const isFav = user ? favSet.has(resource.id) : false;
  return el('div', { class: 'list-item' }, [
    el('div', { class: 'meta' }, [
      el('span', { class: 'chip', onclick: ()=>applyChipFilter({ u: resource.university }) }, resource.university),
      el('span', { class: 'chip', onclick: ()=>applyChipFilter({ y: resource.year }) }, resource.year),
      el('span', { class: 'chip', onclick: ()=>applyChipFilter({ s: resource.subject }) }, resource.subject),
      el('span', { class: 'chip', onclick: ()=>applyChipFilter({ c: resource.classLevel }) }, resource.classLevel),
      el('span', { class: 'chip', onclick: ()=>applyChipFilter({ type: resource.type }) }, resource.type),
      el('span', { class: 'chip' }, resource.isPublic ? 'Public' : 'Privé'),
      resource.fileName ? el('span', { class: 'chip' }, `Fichier: ${resource.fileName} (${formatBytes(resource.fileSize || 0)})`) : null,
      resource.filePath ? el('span', { class: 'chip' }, `Serveur: ${String(resource.filePath).split('/').pop()}`) : null,
      ...(resource.tags || []).map(tag => el('span', { class: 'chip', onclick: ()=>applyChipFilter({ tags: tag }) }, `#${tag}`)),
    ]),
    el('div', { class: 'stack' }, [
      el('strong', {}, resource.title),
      el('span', { class: 'muted' }, `Ajouté le ${formatDate(resource.created_at || resource.createdAt)} par ${getResourceAuthorDisplay(resource)}`),
      el('p', {}, resource.description || ''),
    ]),
    el('div', { class: 'toolbar' }, [
      el('span', { class: 'rating' }, [
        ...[1,2,3,4,5].map(n => el('button', { class: 'btn ghost', title: `${n} étoile(s)`, onclick: ()=> rateResource(resource.id, n) }, String(n))),
        el('span', { class: 'muted' }, ` ${avg}/5 (${ratingCount})`)
      ]),
      el('span', { class: 'spacer' }),
      resource.url ? el('a', { class: 'btn secondary', href: resource.url, target: '_blank', rel: 'noopener' }, 'Ouvrir') : null,
      canPreview(resource) ? el('button', { class: 'btn secondary', onclick: () => openPreview(resource) }, 'Prévisualiser') : null,
      (resource.fileData || resource.filePath) ? el('a', { class: 'btn secondary', href: resource.filePath ? (buildFileUrl(resource)) : resource.fileData, download: resource.fileName || 'fichier' }, 'Télécharger') : null,
      el('a', { class: 'btn', href: `#/details?id=${encodeURIComponent(resource.id)}` }, 'Détails'),
      user ? el('button', { class: 'btn ghost', onclick: () => toggleFavorite(resource.id) }, (isFav ? '★' : '☆') + ' Favori') : null,
      isOwner ? el('button', { class: 'btn secondary', onclick: () => openEditResource(resource.id) }, 'Modifier') : null,
      isOwner ? el('button', { class: 'btn danger', onclick: () => deleteResource(resource.id) }, 'Supprimer') : null,
    ]),
    el('div', { class: 'stack' }, [
      el('strong', {}, 'Commentaires'),
      el('div', { class: 'stack' }, comments.map((c, idx) => el('div', { class: 'card' }, [
        el('div', { class: 'muted' }, `${c.author_name || c.authorDisplay || c.author || 'anonyme'} — ${formatDate(c.created_at || c.createdAt || Date.now())}`),
        el('div', {}, c.content || c.text),
        (userKey && ((c.user_id && c.user_id == 1) || (c.authorKey && c.authorKey === userKey))) ? el('div', { class: 'toolbar' }, [
          el('button', { class: 'btn ghost', onclick: ()=> deleteComment(resource.id, c.id || idx) }, 'Supprimer mon commentaire')
        ]) : null,
      ])) ),
      user ? el('form', { onsubmit: (e) => { e.preventDefault(); submitComment(resource.id, e.target); } }, [
        el('label', { for: `c-${resource.id}` }, 'Ajouter un commentaire'),
        el('textarea', { id: `c-${resource.id}`, name: 'text', required: true, placeholder: 'Votre commentaire...', onkeydown: (e)=>{ const k = e.key || ''; if (k === '/' || k.toLowerCase() === 'n') { e.stopPropagation(); } } }),
        el('div', { class: 'toolbar' }, [
          el('button', { class: 'btn' }, 'Publier'),
        ])
      ]) : el('div', { class: 'card' }, [
        el('div', { class: 'toolbar' }, [
          el('span', { class: 'muted' }, 'Connectez-vous pour commenter et noter.'),
          el('a', { class: 'btn', href: '#/auth' }, 'Se connecter')
        ])
      ])
    ])
  ]);
}

async function rateResource(id, value) {
  const user = getCurrentUser();
  if (!user) { navigate('/auth'); return; }
  
  if (USE_API) {
    try {
      const data = await fetchJSON(`${API_BASE}/resources.php?action=add_rating`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          resource_id: id,
          rating: value
        })
      });
      
      if (data.ok) {
        toast('Merci pour votre note !');
        // Recharger la page pour afficher la nouvelle note
        setTimeout(() => { window.location.reload(); }, 1000);
      } else {
        toast('Erreur lors de l\'ajout de la note.', 'error');
      }
    } catch (error) {
      console.error('API rating error', error);
      toast('Erreur lors de l\'ajout de la note.', 'error');
    }
  } else {
    // Fallback localStorage
    const resources = readStorage(STORAGE_KEYS.RESOURCES, []);
    const r = resources.find(x => x.id === id);
    if (!r) return;
    const userKey = getUserKey(user);
    const voteKey = `edushare:voted:${userKey}:${id}`;
    if (localStorage.getItem(voteKey)) {
      toast('Vous avez déjà noté cette ressource.', 'error');
      return;
    }
    r.ratings.push(value);
    writeStorage(STORAGE_KEYS.RESOURCES, resources);
    localStorage.setItem(voteKey, String(value));
    toast('Merci pour votre note !');
    router();
  }
}

async function submitComment(id, form) {
  const user = getCurrentUser();
  if (!user) { navigate('/auth'); return; }
  const text = new FormData(form).get('text');
  
  if (USE_API) {
    try {
      const data = await fetchJSON(`${API_BASE}/resources.php?action=add_comment`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          resource_id: id,
          content: text,
          author_name: getUserDisplay(user)
        })
      });
      
      if (data.ok) {
        form.reset();
        toast('Commentaire ajouté.');
        // Recharger la page pour afficher le nouveau commentaire
        setTimeout(() => { window.location.reload(); }, 1000);
      } else {
        toast('Erreur lors de l\'ajout du commentaire.', 'error');
      }
    } catch (error) {
      console.error('API comment error', error);
      toast('Erreur lors de l\'ajout du commentaire.', 'error');
    }
  } else {
    // Fallback localStorage
    const resources = readStorage(STORAGE_KEYS.RESOURCES, []);
    const r = resources.find(x => x.id === id);
    if (!r) return;
    const authorKey = getUserKey(user);
    r.comments.push({ authorKey, authorDisplay: getUserDisplay(user), text, createdAt: Date.now() });
    writeStorage(STORAGE_KEYS.RESOURCES, resources);
    form.reset();
    toast('Commentaire ajouté.');
    router();
  }
}

async function deleteComment(resourceId, commentId) {
  const user = getCurrentUser();
  if (!user) { navigate('/auth'); return; }
  
  if (USE_API) {
    try {
      const data = await fetchJSON(`${API_BASE}/resources.php?action=delete_comment`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          comment_id: commentId
        })
      });
      
      if (data.ok) {
        toast('Commentaire supprimé.');
        // Recharger la page pour afficher les changements
        setTimeout(() => { window.location.reload(); }, 1000);
      } else {
        toast('Erreur lors de la suppression du commentaire.', 'error');
      }
    } catch (error) {
      console.error('API delete comment error', error);
      toast('Erreur lors de la suppression du commentaire.', 'error');
    }
  } else {
    // Fallback localStorage
    const list = readStorage(STORAGE_KEYS.RESOURCES, []);
    const r = list.find(x => x.id === resourceId);
    if (!r) return;
    // En local, commentId est l'index
    const commentIndex = Number(commentId);
    const c = r.comments[commentIndex];
    const userKey = getUserKey(user);
    if (!c || c.authorKey !== userKey) { toast('Action non autorisée.', 'error'); return; }
    r.comments.splice(commentIndex, 1);
    writeStorage(STORAGE_KEYS.RESOURCES, list);
    toast('Commentaire supprimé.');
    router();
  }
}

// Pages
function renderHome() {
  const app = qs('#app');
  app.innerHTML = '';
  const recentPlaceholder = el('div', {}, 'Chargement...');
  const recentCard = el('div', { class: 'card' }, [
    el('h2', {}, 'Ressources récentes'),
    recentPlaceholder
  ]);
  app.append(
    el('section', { class: 'stack' }, [
      el('div', { class: 'card' }, [
        el('h1', {}, 'EduShare'),
        el('p', { class: 'muted' }, "Partagez et découvrez des ressources académiques par université, année et matière."),
        el('div', { class: 'toolbar' }, [
          el('a', { class: 'btn', href: '#/recherche' }, 'Chercher des ressources'),
          el('a', { class: 'btn secondary', href: '#/partage' }, 'Partager une ressource'),
        ])
      ]),
      recentCard,
      el('div', { class: 'card' }, [
        el('h2', {}, 'Témoignages'),
        el('div', { class: 'list' }, [
          el('div', { class: 'list-item' }, '"Trouvez tout en un seul endroit !" — Samir'),
          el('div', { class: 'list-item' }, '"Le partage est super simple." — Lina'),
        ])
      ])
    ])
  );
  const loadRecents = async () => {
    try {
      let list = [];
      if (USE_API) {
        list = await apiListResources();
      } else {
        list = readStorage(STORAGE_KEYS.RESOURCES, []);
      }
      list = list.slice().sort((a,b)=> b.createdAt - a.createdAt).slice(0, 6);
      recentCard.replaceChild(renderResourceList(list), recentPlaceholder);
    } catch (e) {
      console.error('Accueil API error', e);
      recentCard.replaceChild(el('div', { class: 'empty' }, 'Impossible de charger.'), recentPlaceholder);
    }
  };
  loadRecents();
}

function renderAuthPage() {
  const app = qs('#app');
  const user = getCurrentUser();
  app.innerHTML = '';
  if (user) {
    app.append(el('div', { class: 'card' }, [
      el('h2', {}, 'Vous êtes connecté'),
      el('p', {}, `Utilisateur: ${getUserDisplay(user)}${user.school?` — ${user.school}`:''}`),
      el('div', { class: 'toolbar' }, [
        el('button', { class: 'btn', onclick: () => { setCurrentUser(null); navigate('/auth'); } }, 'Changer d\'identité'),
        el('button', { class: 'btn danger', onclick: () => { setCurrentUser(null); navigate('/'); } }, 'Se déconnecter')
      ])
    ]));
    return;
  }
  app.append(el('div', { class: 'card' }, [
    el('h2', {}, 'Connexion (locale)'),
    el('form', { class: 'stack', onsubmit: (e) => { e.preventDefault(); handleAuthSubmit(e.target); } }, [
      formField('firstName', 'Prénom', { required: true, placeholder: 'Ex: Samir' }),
      formField('lastName', 'Nom', { required: true, placeholder: 'Ex: Ben Ali' }),
      formField('school', 'École / Université', { required: true, placeholder: 'Ex: Université A' }),
      labeledInput('Anonyme sur le serveur ?', el('select', { name: 'isAnonymous' }, [
        el('option', { value: 'true' }, 'Oui (anonyme)'),
        el('option', { value: 'false', selected: true }, 'Non (afficher mon nom)')
      ])),
      el('div', { class: 'toolbar' }, [
        el('button', { class: 'btn' }, 'Continuer')
      ])
    ])
  ]));
}

function formField(name, labelText, attrs = {}) {
  const input = el('input', { id: name, name, ...attrs });
  return el('div', {}, [ el('label', { for: name }, labelText), input ]);
}

function handleAuthSubmit(form) {
  const data = Object.fromEntries(new FormData(form).entries());
  const user = {
    firstName: (data.firstName || '').trim(),
    lastName: (data.lastName || '').trim(),
    school: (data.school || '').trim(),
    isAnonymous: String(data.isAnonymous) === 'true',
  };
  setCurrentUser(user);
  navigate('/');
}

function renderSearch() {
  const app = qs('#app');
  app.innerHTML = '';
  const params = getHashParams();
  const state = {
    query: '',
    university: '',
    year: '',
    subject: '',
    classLevel: '',
    tags: '',
    sort: 'recent',
    page: 1,
    perPage: 8,
    type: '',
  };
  let catalog = [];

  // Hydrater l'état depuis l'URL
  state.query = params.get('q') || '';
  state.university = params.get('u') || '';
  state.year = params.get('y') || '';
  state.subject = params.get('s') || '';
  state.classLevel = params.get('c') || '';
  state.tags = params.get('tags') || '';
  state.sort = params.get('sort') || 'recent';
  state.page = parseInt(params.get('p') || '1', 10) || 1;
  state.type = params.get('type') || '';
  const perPageParam = parseInt(params.get('pp') || '0', 10);
  if (perPageParam && perPageParam > 0 && perPageParam <= 50) state.perPage = perPageParam;

  // Si aucun paramètre, charger la dernière recherche mémorisée
  if (!(params.toString())) {
    const last = loadLastSearch();
    if (last) {
      state.query = last.q || '';
      state.university = last.u || '';
      state.year = last.y || '';
      state.subject = last.s || '';
      state.classLevel = last.c || '';
      state.sort = last.sort || 'recent';
      state.page = parseInt(last.p || '1', 10) || 1;
    }
  }

  // Datalists pour autocomplétion
  const dlUni = el('datalist', { id: 'dl-uni' });
  const dlSubject = el('datalist', { id: 'dl-subject' });
  const dlTags = el('datalist', { id: 'dl-tags' });

  const controls = el('div', { class: 'card stack' }, [
    el('h2', {}, 'Recherche de ressources'),
    el('div', { class: 'grid' }, [
      labeledInput('Mots-clés', el('input', { value: state.query, placeholder: 'ex: algèbre, réseau...' , oninput: (e)=>{ state.query = e.target.value; }, onkeydown: (e)=>{ if (e.key==='Enter'){ e.preventDefault(); triggerSearch(); } } })),
      labeledInput('Université', el('input', { value: state.university, list: 'dl-uni', oninput: (e)=>{ state.university = e.target.value; }, onkeydown: (e)=>{ if (e.key==='Enter'){ e.preventDefault(); triggerSearch(); } } })),
      labeledInput("Année d'étude", el('input', { value: state.year, placeholder: 'L1, L2, M1...', oninput: (e)=>{ state.year = e.target.value; }, onkeydown: (e)=>{ if (e.key==='Enter'){ e.preventDefault(); triggerSearch(); } } })),
      labeledInput('Matière', el('input', { value: state.subject, list: 'dl-subject', oninput: (e)=>{ state.subject = e.target.value; }, onkeydown: (e)=>{ if (e.key==='Enter'){ e.preventDefault(); triggerSearch(); } } })),
      labeledInput('Classe/Section', el('input', { value: state.classLevel, placeholder: 'L1, L2...', oninput: (e)=>{ state.classLevel = e.target.value; }, onkeydown: (e)=>{ if (e.key==='Enter'){ e.preventDefault(); triggerSearch(); } } })),
      labeledInput('Type', select([
        ['', 'Tous'],
        ['document', 'Document'], ['cours', 'Cours'], ['résumé', 'Résumé'], ['exercice', 'Exercice'], ['autre', 'Autre']
      ], { onchange: (e)=>{ state.type = e.target.value; }, value: state.type })),
      labeledInput('Tags', el('input', { value: state.tags, placeholder: 'ex: math, L1' , list: 'dl-tags', oninput: (e)=>{ state.tags = e.target.value; }, onkeydown: (e)=>{ if (e.key==='Enter'){ e.preventDefault(); triggerSearch(); } } })),
      labeledInput('Tri', select([
        ['recent', 'Plus récentes'],
        ['popular', 'Plus populaires'],
        ['comments', 'Plus commentées'],
        ['title', 'Titre (A→Z)'],
      ], { onchange: (e)=>{ state.sort = e.target.value; } }))
    ]),
    dlUni, dlSubject, dlTags,
    el('div', { class: 'toolbar' }, [
      el('button', { class: 'btn', onclick: ()=> triggerSearch() }, 'Rechercher'),
      el('button', { class: 'btn ghost', onclick: ()=>{ Object.assign(state, { query:'', university:'', year:'', subject:'', classLevel:'', sort:'recent', page:1 }); refresh(true); } }, 'Réinitialiser'),
      el('span', { class: 'spacer' }),
      labeledInput('Par page', select([
        ['8', '8'], ['12', '12'], ['16', '16'], ['24', '24'], ['32', '32']
      ], { onchange: (e)=>{ state.perPage = parseInt(e.target.value,10)||8; }, value: String(state.perPage) })),
      el('button', { class: 'btn ghost', onclick: async ()=>{ try { await navigator.clipboard.writeText(location.href); alert('Lien copié.'); } catch { prompt('Copiez le lien:', location.href); } } }, 'Copier le lien')
    ])
  ]);

  const resultsWrap = el('div', { class: 'card stack' }, [
    el('h3', {}, 'Résultats'),
    el('div', { id: 'results' }, []),
    el('div', { class: 'toolbar' }, [
      el('button', { class: 'btn ghost', onclick: ()=>{ if (state.page>1){ state.page--; refresh(true); } } }, 'Précédent'),
      el('span', { class: 'muted', id: 'page-info' }, ''),
      el('button', { class: 'btn ghost', onclick: ()=>{ state.page++; refresh(true); } }, 'Suivant'),
    ])
  ]);

  app.append(controls, resultsWrap);

  function triggerSearch(){ refresh(true); }

  async function refresh(updateUrl = false) {
    if (updateUrl) {
      const p = new URLSearchParams();
      if (state.query) p.set('q', state.query);
      if (state.university) p.set('u', state.university);
      if (state.year) p.set('y', state.year);
      if (state.subject) p.set('s', state.subject);
      if (state.classLevel) p.set('c', state.classLevel);
      if (state.tags) p.set('tags', state.tags);
      if (state.type) p.set('type', state.type);
      if (state.sort && state.sort !== 'recent') p.set('sort', state.sort);
      if (state.page && state.page !== 1) p.set('p', String(state.page));
      if (state.perPage && state.perPage !== 8) p.set('pp', String(state.perPage));
      setHashQuery(p);
      saveLastSearch(state);
    }
    let all = [];
    if (USE_API) {
      try {
        const apiRows = await apiListResources();
        catalog = apiRows || [];
        rebuildSuggestions(catalog);
        all = searchResources(catalog, state);
      } catch (e) {
        console.error('API list error', e);
        toast('Erreur API - liste', 'error');
        all = [];
      }
    } else {
      catalog = readStorage(STORAGE_KEYS.RESOURCES, []);
      rebuildSuggestions(catalog);
      all = searchResources(catalog, state);
    }
    const total = all.length;
    const start = (state.page - 1) * state.perPage;
    const pageItems = all.slice(start, start + state.perPage);
    renderResults(pageItems, total);
  }
  function renderResults(list, total) {
    const resultsNode = qs('#results');
    resultsNode.innerHTML = '';
    if (total === 0) {
      resultsNode.append(el('div', { class: 'empty' }, 'Aucune ressource trouvée. Essayez de modifier vos critères de recherche.'));
      return;
    }
    resultsNode.append(el('div', { class: 'list' }, list.map(resourceCard)));
    const pageInfo = qs('#page-info');
    if (pageInfo) {
      const maxPage = Math.max(1, Math.ceil(total / state.perPage));
      if (state.page > maxPage) state.page = maxPage;
      pageInfo.textContent = `Page ${state.page} / ${maxPage} (${total} résultat${total > 1 ? 's' : ''})`;
    }
  }
  refresh();
}

function setDatalistOptions(id, items) {
  const dl = document.getElementById(id);
  if (!dl) return;
  dl.innerHTML = '';
  const unique = Array.from(new Set((items || []).map(v => (v || '').trim()).filter(Boolean))).slice(0, 200);
  for (const v of unique) dl.appendChild(el('option', { value: v }));
}

function rebuildSuggestions(list) {
  try {
    const universities = (list || []).map(r => r && r.university).filter(Boolean);
    const subjects = (list || []).map(r => r && r.subject).filter(Boolean);
    const tags = (list || []).flatMap(r => (r && r.tags ? r.tags : [])).map(t => String(t)).filter(Boolean);
    setDatalistOptions('dl-uni', universities);
    setDatalistOptions('dl-subject', subjects);
    setDatalistOptions('dl-tags', tags);
  } catch {}
}

function debounce(fn, wait) {
  let t;
  return function(ev) {
    clearTimeout(t);
    t = setTimeout(() => fn(ev), wait);
  };
}

function labeledInput(labelText, control) {
  return el('div', {}, [ el('label', {}, labelText), control ]);
}

function select(options, attrs = {}) {
  const s = el('select', attrs, options.map(([v, t]) => el('option', { value: v }, t)));
  return s;
}

function searchResources(all, state) {
  const q = (state.query || '').toLowerCase().trim();
  let list = all.filter(r => r && r.isPublic !== false); // Plus permissif pour isPublic
  
  // Recherche textuelle améliorée
  if (q) {
    list = list.filter(r => {
      const searchText = [
        r.title || '',
        r.description || '',
        r.subject || '',
        r.university || '',
        r.year || '',
        r.classLevel || ''
      ].join(' ').toLowerCase();
      return searchText.includes(q);
    });
  }
  
  // Filtres spécifiques
  if (state.university && state.university.trim()) {
    list = list.filter(r => (r.university || '').toLowerCase().includes(state.university.toLowerCase().trim()));
  }
  if (state.year && state.year.trim()) {
    list = list.filter(r => (r.year || '').toLowerCase().includes(state.year.toLowerCase().trim()));
  }
  if (state.subject && state.subject.trim()) {
    list = list.filter(r => (r.subject || '').toLowerCase().includes(state.subject.toLowerCase().trim()));
  }
  if (state.classLevel && state.classLevel.trim()) {
    list = list.filter(r => (r.classLevel || '').toLowerCase().includes(state.classLevel.toLowerCase().trim()));
  }
  
  // Filtre par tags
  if (state.tags && state.tags.trim()) {
    const wanted = state.tags.split(',').map(t=>t.trim().toLowerCase()).filter(Boolean);
    if (wanted.length) {
      list = list.filter(r => {
        const tags = (r.tags || []).map(t=>String(t).toLowerCase());
        return wanted.every(t => tags.includes(t));
      });
    }
  }
  // Filtre par type
  if (state.type && state.type.trim()) {
    const t = state.type.trim().toLowerCase();
    list = list.filter(r => (r.type || '').toLowerCase() === t);
  }
  
  // Tri amélioré
  if (state.sort === 'popular') {
    list = list.sort((a,b) => {
      const aRating = averageRating(a.ratings || []);
      const bRating = averageRating(b.ratings || []);
      if (bRating !== aRating) return bRating - aRating;
      return (b.ratings?.length || 0) - (a.ratings?.length || 0);
    });
  } else if (state.sort === 'comments') {
    list = list.sort((a,b) => {
      const aComments = a.comments?.length || 0;
      const bComments = b.comments?.length || 0;
      if (bComments !== aComments) return bComments - aComments;
      return (b.createdAt || 0) - (a.createdAt || 0);
    });
  } else if (state.sort === 'title') {
    list = list.sort((a,b) => (a.title || '').localeCompare(b.title || ''));
  } else {
    // Tri par date (plus récent en premier)
    list = list.sort((a,b) => (b.createdAt || 0) - (a.createdAt || 0));
  }
  
  return list;
}

function renderShare() {
  const app = qs('#app');
  app.innerHTML = '';
  const user = getCurrentUser();
  const warning = !user ? el('div', { class: 'card' }, [ el('p', {}, "Vous devez être connecté pour partager."), el('a', { class: 'btn', href: '#/auth' }, 'Se connecter') ]) : null;
  const formCard = el('div', { class: 'card' }, [
    el('h2', {}, 'Partager une ressource'),
    el('form', { class: 'stack', onsubmit: (e)=>{ e.preventDefault(); handleShareSubmit(e.target); } }, [
      formField('title', 'Titre', { required: true, placeholder: 'ex: Cours Réseaux M1 - Chapitre 2' }),
      formField('university', 'Université', { required: true }),
      formField('year', 'Année', { required: true, placeholder: 'L1, L2, M1...' }),
      formField('subject', 'Matière', { required: true }),
      formField('classLevel', 'Classe/Section', { placeholder: 'L1, L2...' }),
      labeledInput('Type de ressource', select([
        ['document', 'Document'], ['cours', 'Cours'], ['résumé', 'Résumé'], ['exercice', 'Exercice'], ['autre', 'Autre']
      ], { name: 'type' })),
      formField('tags', 'Tags (séparés par des virgules)', { placeholder: 'ex: math, L1, examen' }),
      el('div', {}, [ el('label', { for: 'url' }, 'Lien (facultatif)'), el('input', { id: 'url', name: 'url', type: 'url', placeholder: 'https://...' }) ]),
      el('div', {}, [ el('label', { for: 'file' }, `Fichier (facultatif, ≤ ${formatBytes(MAX_UPLOAD_BYTES)})`), el('input', { id: 'file', name: 'file', type: 'file', accept: 'application/pdf,.doc,.docx,.ppt,.pptx,.txt,.zip,image/*' }) ]),
      el('div', { class: 'progress hidden', id: 'upload-progress' }, [ el('span', {}) ]),
      el('div', { class: 'muted' }, USE_API ? 'Les fichiers sont hébergés sur le serveur.' : 'Sans serveur: les fichiers sont stockés en base64 dans votre navigateur.'),
      el('div', { class: 'dropzone', id: 'dropzone' }, 'Glissez-déposez un fichier ici'),
      el('div', {}, [ el('label', { for: 'description' }, 'Description'), el('textarea', { id: 'description', name: 'description' }) ]),
      el('div', {}, [
        el('label', { for: 'isPublic' }, 'Visibilité'),
        el('select', { id: 'isPublic', name: 'isPublic' }, [
          el('option', { value: 'true' }, 'Publique'),
          el('option', { value: 'false' }, 'Privée'),
        ])
      ]),
      el('div', { class: 'toolbar' }, [
        el('button', { class: 'btn' }, 'Publier')
      ])
    ])
  ]);
  app.append(...[warning, formCard].filter(Boolean));

  // Drag & Drop
  const dz = document.getElementById('dropzone');
  const fileInput = document.getElementById('file');
  if (dz && fileInput) {
    dz.addEventListener('dragover', (e)=>{ e.preventDefault(); dz.classList.add('dragover'); });
    dz.addEventListener('dragleave', ()=> dz.classList.remove('dragover'));
    dz.addEventListener('drop', (e)=>{ e.preventDefault(); dz.classList.remove('dragover'); const f = e.dataTransfer.files && e.dataTransfer.files[0]; if (f) { fileInput.files = e.dataTransfer.files; dz.textContent = `Fichier sélectionné: ${f.name}`; } });
  }
}

async function handleShareSubmit(form) {
  const user = getCurrentUser();
  if (!user) { navigate('/auth'); return; }
  const data = Object.fromEntries(new FormData(form).entries());
  const fileInput = form.querySelector('input[name="file"]');
  const file = fileInput && fileInput.files && fileInput.files[0] ? fileInput.files[0] : null;

  if (!data.url && !file) {
    alert('Veuillez fournir un lien ou un fichier.');
    return;
  }
  if (file && file.size > MAX_UPLOAD_BYTES) {
    alert(`Fichier trop volumineux (${formatBytes(file.size)}). Limite: ${formatBytes(MAX_UPLOAD_BYTES)}.`);
    return;
  }
  const resources = USE_API ? [] : readStorage(STORAGE_KEYS.RESOURCES, []);
  const item = {
    id: crypto.randomUUID(),
    title: data.title,
    university: data.university,
    year: data.year,
    subject: data.subject,
    classLevel: data.classLevel || '',
    type: data.type || 'autre',
    description: data.description || '',
    url: data.url || '',
    isPublic: data.isPublic === 'true',
    createdAt: Date.now(),
    ratings: [],
    comments: [],
    authorKey: getUserKey(user),
    authorName: getUserDisplay(user),
    isAnonymous: !!user.isAnonymous,
    tags: (data.tags || '').split(',').map(t=>t.trim()).filter(Boolean),
  };
  if (file) {
    try {
      // Upload serveur avec progression
      const prog = document.getElementById('upload-progress');
      const progBar = prog ? prog.querySelector('span') : null;
      if (prog) prog.classList.remove('hidden');
      if (USE_API) {
        const res = await uploadFileWithProgress(file, (pct)=>{ if (progBar) progBar.style.width = pct + '%'; });
        if (!res || !res.ok) { if (prog) prog.classList.add('hidden'); alert('Échec upload serveur'); return; }
        item.filePath = res.file_path;
      }
      // Conserver aussi une copie locale pour preview immédiate
      const dataUrl = await readFileAsDataURL(file);
      item.fileName = file.name;
      item.fileType = file.type || 'application/octet-stream';
      item.fileSize = file.size;
      item.fileData = dataUrl;
    } catch (e) {
      console.error('Erreur upload/lecture fichier', e);
      alert("Impossible de téléverser ce fichier.");
      return;
    }
  }
  if (USE_API) {
    try {
      const res = await apiCreateResource(item);
      const newId = (res && (res.data && (res.data.id || res.data.insertId))) ? String(res.data.id || res.data.insertId) : ((res && (res.id || res.insertId)) ? String(res.id || res.insertId) : null);
      if (newId) {
        addMineId(getUserKey(user), newId);
        if (item.fileData) {
          setFileMapItem(newId, { fileName: item.fileName, fileType: item.fileType, fileSize: item.fileSize, fileData: item.fileData });
        }
      }
      const prog = document.getElementById('upload-progress');
      if (prog) { prog.classList.add('hidden'); const bar = prog.querySelector('span'); if (bar) bar.style.width = '0%'; }
      toast('Ressource créée avec succès !');
      // Rediriger vers la page de recherche pour voir la nouvelle ressource
      setTimeout(() => {
        navigate('/recherche');
      }, 1000);
      return;
    } catch (e) {
      console.error('API create error', e);
      toast('Erreur API - création', 'error');
      return;
    }
  } else {
    resources.unshift(item);
    writeStorage(STORAGE_KEYS.RESOURCES, resources);
  }
  pushNotification({
    title: 'Nouvelle ressource',
    body: `${item.title} (${item.subject})`,
    filter: { university: item.university, year: item.year, subject: item.subject },
  });
  form.reset();
  navigate('/recherche');
}

async function renderProfile() {
  const app = qs('#app');
  app.innerHTML = '';
  const user = getCurrentUser();
  if (!user) { navigate('/auth'); return; }
  let all = [];
  if (USE_API) {
    // côté API, on reconstruit "mes ressources" via mineIds
    const myKey = getUserKey(user);
    const myIds = getMineIds(myKey);
    try { all = await apiListResources(); } catch (e) { all = []; }
    var mine = all.filter(r => myIds.has(String(r.id)) || isOwnerResource(r));
  } else {
    all = readStorage(STORAGE_KEYS.RESOURCES, []);
    var myKey = getUserKey(user);
    var mine = all.filter(r => r.authorKey === myKey);
  }
  const favIds = getFavorites(getUserKey(user));
  const favs = all.filter(r => favIds.has(r.id));
  const totalShared = mine.length;
  const totalLikes = mine.reduce((acc, r) => acc + r.ratings.length, 0);
  const totalComments = mine.reduce((acc, r) => acc + r.comments.length, 0);
  app.append(
    el('div', { class: 'card stack' }, [
      el('h2', {}, 'Mon profil'),
      el('div', {}, `${getUserDisplay(user)}${user.school?` — ${user.school}`:''}`),
      el('div', { class: 'meta' }, [
        el('span', { class: 'chip' }, `Badge: Partageur (${totalShared})`),
        el('span', { class: 'chip' }, `Appréciations (${totalLikes})`),
        el('span', { class: 'chip' }, `Commentaires (${totalComments})`),
      ]),
      el('h3', {}, 'Mes ressources'),
      mine.length ? el('div', { class: 'list' }, mine.map(resourceCard)) : el('div', { class: 'empty' }, 'Aucune ressource pour le moment.'),
      el('h3', {}, 'Mes favoris'),
      favs.length ? el('div', { class: 'list' }, favs.map(resourceCard)) : el('div', { class: 'empty' }, 'Aucun favori pour le moment.'),
    ])
  );
}

function renderNotifications() {
  const app = qs('#app');
  app.innerHTML = '';
  const list = readStorage(STORAGE_KEYS.NOTIFICATIONS, []);
  app.append(
    el('div', { class: 'card stack' }, [
      el('h2', {}, 'Notifications'),
      list.length ? el('div', { class: 'list' }, list.map(n => el('div', { class: 'list-item' }, [
        el('strong', {}, n.title),
        el('div', {}, n.body),
        el('div', { class: 'muted' }, formatDate(n.createdAt)),
      ]))) : el('div', { class: 'empty' }, 'Aucune notification.'),
    ])
  );
}

function pushNotification(n) {
  const list = readStorage(STORAGE_KEYS.NOTIFICATIONS, []);
  list.unshift({ ...n, createdAt: Date.now() });
  writeStorage(STORAGE_KEYS.NOTIFICATIONS, list);
}

function canPreview(resource) {
  if (resource.fileData) {
    return resource.fileType ? (resource.fileType.startsWith('image/') || resource.fileType === 'application/pdf') : true;
  }
  const serverUrl = resource.filePath ? (FILE_BASE + resource.filePath) : null;
  const link = serverUrl || resource.url || '';
  if (link) {
    const u = String(link).toLowerCase();
    return u.endsWith('.pdf') || u.match(/\.(png|jpe?g|gif|webp|svg)$/);
  }
  return false;
}

function previewSource(resource) {
  if (resource.fileData) return resource.fileData;
  if (resource.filePath) return buildFileUrl(resource);
  return resource.url;
}

function openPreview(resource) {
  const src = previewSource(resource);
  const isImage = (resource.fileType && resource.fileType.startsWith('image/')) || /\.(png|jpe?g|gif|webp|svg)$/i.test(src);
  const isPdf = (resource.fileType === 'application/pdf') || /\.pdf$/i.test(src);
  
  const backdrop = el('div', { class: 'modal-backdrop', onclick: (e)=>{ if (e.target === e.currentTarget) closePreview(backdrop); } }, [
    el('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true' }, [
      el('header', {}, [
        el('strong', {}, resource.title || 'Aperçu'),
        el('div', { class: 'toolbar' }, [
          isPdf ? el('a', { class: 'btn secondary', href: src, target: '_blank', download: resource.fileName || 'document.pdf' }, 'Télécharger PDF') : null,
          el('button', { class: 'btn ghost', onclick: ()=> closePreview(backdrop) }, 'Fermer')
        ])
      ]),
      el('div', { class: 'content' }, [
        isImage ? el('img', { class: 'preview-img', src, alt: resource.title || 'Image' }) : null,
        isPdf ? el('div', { class: 'pdf-container' }, [
          el('iframe', { 
            class: 'preview-iframe', 
            src: src,
            title: resource.title || 'Document PDF',
            sandbox: 'allow-same-origin allow-scripts'
          }),
          el('div', { class: 'pdf-fallback' }, [
            el('p', {}, 'Si le PDF ne s\'affiche pas, cliquez sur "Télécharger PDF" ci-dessus.'),
            el('a', { class: 'btn', href: src, target: '_blank' }, 'Ouvrir dans un nouvel onglet')
          ])
        ]) : null,
        (!isImage && !isPdf) ? el('div', { class: 'empty' }, 'Aperçu non disponible pour ce type de fichier.') : null,
      ])
    ])
  ]);
  document.body.classList.add('modal-open');
  document.body.appendChild(backdrop);
  const onKey = (ev)=>{ if (ev.key === 'Escape') { closePreview(backdrop); } };
  backdrop._onKey = onKey;
  window.addEventListener('keydown', onKey);
  const focusable = backdrop.querySelector('button, [href], input, select, textarea');
  if (focusable) focusable.focus();
}

function closePreview(backdrop) {
  if (!backdrop) return;
  window.removeEventListener('keydown', backdrop._onKey || (()=>{}));
  document.body.classList.remove('modal-open');
  backdrop.remove();
}

async function openEditResource(resourceId) {
  const resource = await findResourceById(resourceId);
  if (!resource) {
    toast('Ressource introuvable', 'error');
    return;
  }
  
  const form = el('form', { class: 'stack', onsubmit: async (e)=>{ e.preventDefault(); await submitEditResource(resourceId, e.target); } }, [
    formField('title', 'Titre', { required: true, value: resource.title }),
    formField('university', 'Université', { required: true, value: resource.university }),
    formField('year', 'Année', { required: true, value: resource.year }),
    formField('subject', 'Matière', { required: true, value: resource.subject }),
    formField('classLevel', 'Classe/Section', { value: resource.classLevel || '' }),
    labeledInput('Type de ressource', select([
      ['document', 'Document'], ['cours', 'Cours'], ['résumé', 'Résumé'], ['exercice', 'Exercice'], ['autre', 'Autre']
    ], { name: 'type', value: resource.type || 'document' })),
    el('div', {}, [ el('label', { for: 'url' }, 'Lien (facultatif)'), el('input', { id: 'url', name: 'url', type: 'url', value: resource.url || '' }) ]),
    el('div', {}, [ el('label', { for: 'file' }, 'Remplacer le fichier (≤ 20 Mo)'), el('input', { id: 'file', name: 'file', type: 'file', accept: 'application/pdf,.doc,.docx,.ppt,.pptx,.txt,.zip,image/*' }) ]),
    el('div', {}, [ el('label', { for: 'description' }, 'Description'), el('textarea', { id: 'description', name: 'description' }, resource.description || '') ]),
    el('div', {}, [
      el('label', { for: 'isPublic' }, 'Visibilité'),
      (function(){
        const s = select([
          ['true', 'Publique'],
          ['false', 'Privée']
        ], { id: 'isPublic', name: 'isPublic' });
        s.value = resource.isPublic ? 'true' : 'false';
        return s;
      })()
    ]),
    el('div', { class: 'toolbar' }, [
      el('button', { class: 'btn' }, 'Enregistrer'),
      el('button', { class: 'btn ghost', type: 'button', onclick: ()=> closePreview(backdrop) }, 'Annuler')
    ])
  ]);
  
  const backdrop = el('div', { class: 'modal-backdrop', onclick: (e)=>{ if (e.target === e.currentTarget) closePreview(backdrop); } }, [
    el('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true' }, [
      el('header', {}, [ el('strong', {}, 'Modifier la ressource'), el('button', { class: 'btn ghost', onclick: ()=> closePreview(backdrop) }, 'Fermer') ]),
      el('div', { class: 'content' }, [ form ])
    ])
  ]);
  
  document.body.classList.add('modal-open');
  document.body.appendChild(backdrop);
  const onKey = (ev)=>{ if (ev.key === 'Escape') { closePreview(backdrop); } };
  backdrop._onKey = onKey;
  window.addEventListener('keydown', onKey);
}

async function submitEditResource(resourceId, form) {
  const user = getCurrentUser();
  if (!user) { navigate('/auth'); return; }
  const data = Object.fromEntries(new FormData(form).entries());
  
  if (USE_API) {
    try {
      let filePath = null;
      
      // Gérer le nouveau fichier s'il y en a un
      const fileInput = form.querySelector('input[name="file"]');
      const file = fileInput && fileInput.files && fileInput.files[0] ? fileInput.files[0] : null;
      if (file) {
        if (file.size > MAX_UPLOAD_BYTES) {
          toast('Fichier trop volumineux', 'error');
          return;
        }
        // Upload du nouveau fichier (API fiable)
        const up = await apiUploadFile(file);
        if (up && up.ok) {
          filePath = up.file_path;
        } else {
          toast('Erreur lors de l\'upload du fichier', 'error');
          return;
        }
      }
      
      // Préparer les données pour l'API
      const updateData = {
        id: resourceId,
        title: data.title,
        university: data.university,
        year: data.year,
        subject: data.subject,
        classLevel: data.classLevel || '',
        type: data.type || 'document',
        description: data.description || '',
        url: data.url || '',
        isPublic: data.isPublic === 'true',
        author_name: getUserDisplay(user),
        is_anonymous: user.isAnonymous || false
      };
      
      if (filePath) {
        updateData.file_path = filePath;
      }
      
      // Envoyer la requête de mise à jour
      const response = await fetch(`${API_BASE}/resources.php?action=update`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updateData)
      });
      
      const result = await fetchJSON(response);
      if (result.ok) {
        toast('Ressource modifiée avec succès');
        // Recharger la page pour mettre à jour l'affichage
        setTimeout(() => { window.location.reload(); }, 1000);
      } else {
        toast('Erreur lors de la modification: ' + (result.error || 'Erreur inconnue'), 'error');
      }
    } catch (e) {
      console.error('Erreur modification API', e);
      toast('Erreur lors de la modification', 'error');
    }
  } else {
    const list = readStorage(STORAGE_KEYS.RESOURCES, []);
    const userKey = getUserKey(user);
    const idx = list.findIndex(r => r.id === resourceId && r.authorKey === userKey);
    if (idx === -1) { 
      toast('Modification non autorisée', 'error'); 
      return; 
    }
    const prev = list[idx];
    const fileInput = form.querySelector('input[name="file"]');
    const file = fileInput && fileInput.files && fileInput.files[0] ? fileInput.files[0] : null;
    if (file && file.size > MAX_UPLOAD_BYTES) { 
      toast('Fichier trop volumineux', 'error'); 
      return; 
    }
    const updated = {
      ...prev,
      title: data.title,
      university: data.university,
      year: data.year,
      subject: data.subject,
      classLevel: data.classLevel || '',
      type: data.type || prev.type,
      description: data.description || '',
      url: data.url || '',
      isPublic: data.isPublic === 'true',
    };
    if (file) {
      const dataUrl = await readFileAsDataURL(file);
      updated.fileName = file.name;
      updated.fileType = file.type || 'application/octet-stream';
      updated.fileSize = file.size;
      updated.fileData = dataUrl;
    }
    list[idx] = updated;
    writeStorage(STORAGE_KEYS.RESOURCES, list);
    toast('Ressource modifiée avec succès');
  }
  
  const modal = document.querySelector('.modal-backdrop');
  if (modal) closePreview(modal);
  router();
}

function toggleFavorite(resourceId) {
  const user = getCurrentUser();
  if (!user) { navigate('/auth'); return; }
  const userKey = getUserKey(user);
  const favs = getFavorites(userKey);
  if (favs.has(resourceId)) favs.delete(resourceId); else favs.add(resourceId);
  setFavorites(userKey, favs);
  router();
}

async function deleteResource(id) {
  const user = getCurrentUser();
  if (!user) { navigate('/auth'); return; }
  
  // Confirmation avec plus de détails
  const resource = await findResourceById(id);
  const resourceTitle = resource ? resource.title : 'cette ressource';
  if (!confirm(`Êtes-vous sûr de vouloir supprimer "${resourceTitle}" ?\n\nCette action est irréversible.`)) return;
  
  if (USE_API) {
    try {
      const response = await fetch(`${API_BASE}/resources.php?action=delete`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: id })
      });
      const result = await fetchJSON(response);
      if (result.ok) {
        toast('Ressource supprimée avec succès');
        // Recharger la page pour mettre à jour l'affichage
        setTimeout(() => { window.location.reload(); }, 1000);
      } else {
        toast('Erreur lors de la suppression: ' + (result.error || 'Erreur inconnue'), 'error');
      }
    } catch (e) {
      console.error('Erreur suppression API', e);
      toast('Erreur lors de la suppression', 'error');
    }
  } else {
    const list = readStorage(STORAGE_KEYS.RESOURCES, []);
    const userKey = getUserKey(user);
    const finalList = list.filter(r => !(r.id === id && r.authorKey === userKey));
    writeStorage(STORAGE_KEYS.RESOURCES, finalList);
    toast('Ressource supprimée');
  }
  router();
}

async function findResourceById(id) {
  if (USE_API) {
    try {
      const all = await apiListResources();
      return all.find(r => r.id === id);
    } catch (e) {
      return null;
    }
  } else {
    const list = readStorage(STORAGE_KEYS.RESOURCES, []);
    return list.find(r => r.id === id);
  }
}

function renderHelp() {
  const app = qs('#app');
  app.innerHTML = '';
  app.append(
    el('div', { class: 'card stack' }, [
      el('h2', {}, 'Aide & FAQ'),
      el('div', { class: 'stack' }, [
        el('div', { class: 'list-item' }, [
          el('strong', {}, 'Comment fonctionne ce site ?'),
          el('p', {}, "Version démo sans base de données. Les données sont stockées dans votre navigateur."),
        ]),
        el('div', { class: 'list-item' }, [
          el('strong', {}, 'Puis-je supprimer mes données ?'),
          el('p', {}, "Oui, vous pouvez réinitialiser ci-dessous."),
          el('div', { class: 'toolbar' }, [
            el('button', { class: 'btn danger', onclick: ()=>{ if (confirm('Tout réinitialiser ?')) { clearAllData(); } } }, 'Réinitialiser les données')
          ])
        ]),
      ])
    ])
  );
}

function clearAllData() {
  const keys = [];
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (k && k.startsWith('edushare:')) keys.push(k);
  }
  for (const k of keys) localStorage.removeItem(k);
  location.reload();
}

function renderNotFound() {
  const app = qs('#app');
  app.innerHTML = '';
  app.append(el('div', { class: 'card' }, [
    el('h2', {}, 'Page introuvable'),
    el('a', { href: '#/' }, 'Revenir à l\'accueil')
  ]));
}

function renderResourceList(list) {
  if (!list || list.length === 0) return el('div', { class: 'empty' }, 'Rien à afficher.');
  return el('div', { class: 'list' }, list.map(resourceCard));
}

// Naviguer vers la recherche avec des filtres issus d'une puce
function applyChipFilter(partial) {
  navigate('/recherche');
  const p = getHashParams();
  // Réinitialiser page
  p.delete('p');
  for (const [k, v] of Object.entries(partial || {})) {
    if (!v) continue;
    // gestion tags: concat si déjà présent
    if (k === 'tags') {
      const existing = p.get('tags') || '';
      const arr = existing ? existing.split(',') : [];
      if (!arr.includes(v)) arr.push(v);
      p.set('tags', arr.filter(Boolean).join(','));
    } else {
      p.set(k, v);
    }
  }
  setHashQuery(p);
}

// Initialisation
function init() {
  seedIfEmpty();
  applyTheme(getStoredTheme());
  attachThemeListenerIfNeeded();
  renderAuth();
  renderHeaderExtras();
  const y = document.getElementById('year');
  if (y) y.textContent = new Date().getFullYear();
  window.addEventListener('hashchange', router);
  router();

  // Enregistrement service worker
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./service-worker.js').catch(()=>{});
  }

  // Raccourcis
  window.addEventListener('keydown', (e) => {
    const active = document.activeElement;
    const tag = active && active.tagName ? active.tagName.toUpperCase() : '';
    const isTyping = (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || (active && active.isContentEditable));
    if (isTyping) return;
    if (e.key === '/' && !e.ctrlKey && !e.metaKey) { e.preventDefault(); navigate('/recherche'); setTimeout(()=>{ const el = document.querySelector('input[placeholder*="algèbre"], input[placeholder*="algèbre"]'); if (el) el.focus(); }, 0); }
    if (e.key.toLowerCase() === 'n' && !e.ctrlKey && !e.metaKey) { navigate('/partage'); }
  });
}

document.addEventListener('DOMContentLoaded', init);


