<?php
require_once 'config.php';

// Ajouter quelques ressources de test
try {
    // Vérifier si des ressources existent déjà
    $checkSql = "SELECT COUNT(*) as count FROM resources";
    $checkStmt = $pdo->prepare($checkSql);
    $checkStmt->execute();
    $result = $checkStmt->fetch();
    
    if ($result['count'] == 0) {
        echo "Ajout de données de test...\n";
        
        // Insérer des ressources de test
        $resources = [
            [
                'title' => 'Cours de Mathématiques - Analyse L1',
                'university' => 'Université de Paris',
                'year' => 'L1',
                'subject' => 'Mathématiques',
                'class_level' => 'L1',
                'type' => 'cours',
                'description' => 'Cours complet sur l\'analyse mathématique niveau L1',
                'url' => '',
                'file_path' => null,
                'is_public' => 1,
                'author_name' => 'Prof. Martin',
                'is_anonymous' => 0
            ],
            [
                'title' => 'Exercices Physique - Mécanique',
                'university' => 'Université Lyon',
                'year' => 'L2',
                'subject' => 'Physique',
                'class_level' => 'L2',
                'type' => 'exercice',
                'description' => 'Série d\'exercices sur la mécanique newtonienne',
                'url' => '',
                'file_path' => null,
                'is_public' => 1,
                'author_name' => 'Prof. Durand',
                'is_anonymous' => 0
            ],
            [
                'title' => 'Résumé Algorithmique',
                'university' => 'Université Toulouse',
                'year' => 'L3',
                'subject' => 'Informatique',
                'class_level' => 'L3',
                'type' => 'résumé',
                'description' => 'Résumé des principaux algorithmes de tri et de recherche',
                'url' => '',
                'file_path' => null,
                'is_public' => 1,
                'author_name' => 'Étudiant anonyme',
                'is_anonymous' => 1
            ]
        ];
        
        $sql = "INSERT INTO resources (title, university, year, subject, class_level, type, description, url, file_path, is_public, author_name, is_anonymous) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        
        foreach ($resources as $resource) {
            $stmt->execute([
                $resource['title'],
                $resource['university'],
                $resource['year'],
                $resource['subject'],
                $resource['class_level'],
                $resource['type'],
                $resource['description'],
                $resource['url'],
                $resource['file_path'],
                $resource['is_public'],
                $resource['author_name'],
                $resource['is_anonymous']
            ]);
            echo "Ressource ajoutée: " . $resource['title'] . "\n";
        }
        
        echo "Données de test ajoutées avec succès!\n";
    } else {
        echo "Des ressources existent déjà ({$result['count']} trouvées).\n";
    }
    
} catch (PDOException $e) {
    echo "Erreur: " . $e->getMessage() . "\n";
}
?>
