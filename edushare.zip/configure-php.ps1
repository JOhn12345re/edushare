# Script de configuration PHP avec vérification
Write-Host "🔧 Configuration de PHP..." -ForegroundColor Yellow

# Vérifier si php.exe existe
if (Test-Path "C:\php\php.exe") {
    Write-Host "✅ PHP trouvé dans C:\php" -ForegroundColor Green
    
    # Afficher la version
    & "C:\php\php.exe" --version
    
    # Ajouter au PATH
    $currentPath = [Environment]::GetEnvironmentVariable("Path", [EnvironmentVariableTarget]::User)
    if ($currentPath -notlike "*C:\php*") {
        Write-Host "➕ Ajout de C:\php au PATH utilisateur..." -ForegroundColor Yellow
        [Environment]::SetEnvironmentVariable("Path", $currentPath + ";C:\php", [EnvironmentVariableTarget]::User)
        Write-Host "✅ PATH configuré!" -ForegroundColor Green
    } else {
        Write-Host "ℹ️ C:\php déjà dans le PATH" -ForegroundColor Blue
    }
    
    # Créer php.ini
    if (-not (Test-Path "C:\php\php.ini")) {
        if (Test-Path "C:\php\php.ini-development") {
            Copy-Item "C:\php\php.ini-development" "C:\php\php.ini"
            Write-Host "✅ php.ini créé" -ForegroundColor Green
        }
    }
    
    Write-Host "🎉 Configuration terminée!" -ForegroundColor Green
    Write-Host "💡 Redémarrez votre terminal et tapez: php --version" -ForegroundColor Yellow
    
} else {
    Write-Host "❌ php.exe non trouvé dans C:\php" -ForegroundColor Red
    Write-Host "📥 Veuillez d'abord extraire PHP dans C:\php" -ForegroundColor Yellow
    
    # Vérifier les téléchargements
    $downloads = "$env:USERPROFILE\Downloads\php-*.zip"
    $phpFiles = Get-ChildItem $downloads -ErrorAction SilentlyContinue
    if ($phpFiles) {
        Write-Host "📁 Fichiers PHP trouvés dans Téléchargements:" -ForegroundColor Blue
        $phpFiles | ForEach-Object { Write-Host "  - $($_.Name)" -ForegroundColor Blue }
    }
}

Read-Host "Appuyez sur Entrée pour continuer..."
